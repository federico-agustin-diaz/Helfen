// key extractor temporary
const keyExtractor = (item: any, index: number) => index.toString();
export default keyExtractor;
